document.addEventListener('DOMContentLoaded', () => {
    const quote = document.querySelector('.quote');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target); // animate once
            }
        });
    }, { threshold: 0.5 });

    if (quote) {
        observer.observe(quote);
    }
});
